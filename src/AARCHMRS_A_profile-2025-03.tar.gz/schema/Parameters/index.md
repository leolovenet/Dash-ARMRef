<!-- Copyright (c) 2010-2025 Arm Limited or its affiliates. All rights reserved. -->
<!-- This document is Non_confidential. This document may only be used and distributed in
accordance with the terms of the agreement entered into by Arm and the party that
Arm delivered this document to.

The data contained in this file is preliminary and subject to change or
correction following further review.
 -->
# Parameters

Parameters represent nodes in the $(Features) graph - they are items of data that the system knows
about. Constraints are edges that connect Parameters.

A given parameter has a name, and might have a domain of values attached to it. It may also
have constraints that affect its value - see $(Traits.HasConstraints) for more information.

