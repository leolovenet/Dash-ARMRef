<!-- Copyright (c) 2010-2025 Arm Limited or its affiliates. All rights reserved. -->
<!-- This document is Non-confidential and licensed under the BSD 3-clause license. -->
render_when: Instruction.Rules.Rule

# Rules

Rules describe how assembly symbols are assembled (from symbols to encoding field values)
and disassembled (from encoding field values to symbols). There are three types of rule:

