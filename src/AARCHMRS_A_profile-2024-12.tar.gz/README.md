# AARCHMRS containing the FEATURES.json for A-profile Architecture

## Introduction

This is the Arm Architecture Machine Readable Specification containing the
Features.json for A-profile Architecture.

The [notice](docs/notice.html) gives details of the terms and conditions under which this package
is provided.

The package contains:

 - [`Features.json`](Features.json) contains the source data for the architecture map of the
   features.
 - [`schema`](schema/) the JSON schema for the data.
 - [`docs`](docs/index.html) is a rendered view of the schema which also includes user guides and
   definitions to help understanding.


