<!-- Copyright (c) 2010-2025 Arm Limited or its affiliates. All rights reserved. -->
<!-- This document is Non_confidential. This document may only be used and distributed in
accordance with the terms of the agreement entered into by Arm and the party that
Arm delivered this document to.

The data contained in this file is preliminary and subject to change or
correction following further review.
 -->
# Traits

Traits are purpose-specific additional schema elements. The name indicates which schema element it affects. For example, the HasCondition trait is used within the Condition schema element.

